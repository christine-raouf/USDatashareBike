import time
import numpy as np
import pandas as pd
import sys

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }

Months= ['january','february','march','april','may','june','all'] 
#Not_Included_Months = {'july','august','september','october','november','december'}
Days = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday','all']          

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    
    try:
    # get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
        city = input("Choose a city you want to explore data for:Chicago, New York City, Washington\n").lower()
        print(city)
        while city not in CITY_DATA:
            city = input("Incorrect city please choose a city you want to explore data for: Chicago,New York City, Washington\n").lower()
    except KeyboardInterrupt:
        print("Try again by re-running the script") 
        sys.exit()       
    
    
    try:
        # get user input for month (all, january, february, ... , june)
        month = input("Please enter the month you want to filter by: January,February,March, till June as no data is available for the second half of the year or enter all if you don't want to apply filter by month:\n").lower()
        while month not in Months:
            month = input("Please enter a valid month value by entering month full name or all for no filter by month:\n").lower()            
    except KeyboardInterrupt:
        print("Try again by re-running the script") 
        sys.exit()         

    try:
        # get user input for day of week (all, monday, tuesday, ... sunday)
        day = input("Please enter the day you want to filter by: Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday or enter all if you don't want to apply filter by day:\n").lower()
        while day not in Days:
            day = input("Please enter a valid day value by entering day  name or all for no filter by day:").lower()   
    except KeyboardInterrupt:
        print("Try again by re-running the script") 
        sys.exit()        


    print('-'*40)
    #print("{} {} {}".format(city,month,day))
    return city, month, day


def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    filename = CITY_DATA[city]
    df = pd.read_csv(filename)

    df['Start Trip Month']=pd.to_datetime(df['Start Time']).dt.month_name()
    df['End Trip Month']=pd.to_datetime(df['End Time']).dt.month_name()
    df['Start Trip Day']=pd.to_datetime(df['Start Time']).dt.day_name()
    df['End Trip Day']=pd.to_datetime(df['End Time']).dt.day_name() 
    
    if month != 'all':
            df = df[(df['Start Trip Month'] == month.title())]

    if day != 'all':
        df = df[(df['Start Trip Day'] == day.title())]


    
    """
    Print Trips starting one day and finishes next day
    """
    #print(df[(df['Start Trip Day'] != df['End Trip Day'])])

    """
    Print Trips starting in a month and finishes next one so in that case trip started the last day of month and fnishes next day which will be the start of new month
    """
    #print(df[(df['Start Trip Month'] != df['End Trip Month'])])
    
    #print(df.columns)
    return df


def time_stats(df,month,day):

    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    if month == "all":
        common_month=df['Start Trip Month'].mode()
        print("Common_month for trips:")
        print(common_month)
        print("\n")
    

    if day == "all":
        # display the most common day of week
        common_day=df['Start Trip Day'].mode()
        print("Common_day for trips")
        print(common_day)
        print("\n")

    # display the most common start hour
    common_hour=pd.to_datetime(df["Start Time"]).dt.hour.mode()
    print("Common start hour for trips:")
    print(common_hour)
    print("\n")

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display most commonly used start station
    common_start_stations = list(df['Start Station'].mode().to_dict().values())
    common_start_station_string = ""
    for common_start_station in common_start_stations:
        common_start_station_string += common_start_station+","
    common_start_station_string=common_start_station_string[0:-1]

    print("The frequent start stations for trips are:{}".format(common_start_station_string))

    # display most commonly used end station
    common_end_stations = list(df['End Station'].mode().to_dict().values())
    common_end_station_string = ""
    for common_end_station in common_end_stations:
        common_end_station_string += common_end_station+","   
   
    common_end_station_string=common_end_station_string[0:-1]    
    print("The frequent end stations for trips are:{}".format(common_end_station_string))

    # display most frequent combination of start station and end station trip
    df_start_end_station = df[['Start Station','End Station']]
    #print(df_start_end_station.head())
    original_station_start_end_columns=df_start_end_station.columns.tolist()
    df_start_end_station = df_start_end_station.value_counts().to_frame().reset_index()

    original_station_start_end_columns.append("counts")
    df_start_end_station.set_axis(original_station_start_end_columns,axis='columns',inplace=True)

    common_start_end_station = df_start_end_station[(df_start_end_station['counts'] == df_start_end_station['counts'].max())]
    print("The start and end stations for most frequent trip is:")
    print(common_start_end_station)

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time
    print("Total travel time in hrs:")
    print(df['Trip Duration'].sum()/3600)
    print("\n")

    # display mean travel time
    print("Average travel time:")
    print(df['Trip Duration'].mean())
    print("\n")

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def user_stats(df,city):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    print("Users count based on account type:\n")
    user_types_count=df["User Type"].value_counts().to_frame().reset_index()
    user_types_count.set_axis(["User Type","count"],axis='columns',inplace=True)
    print(user_types_count)

    if city != "washington":
        # Display counts of gender
        print("Count of users based on gender")
        user_gender_count=df["Gender"].value_counts().to_frame().reset_index()
        user_gender_count.set_axis(["Gender","count"],axis='columns',inplace=True)
        print(user_gender_count)  
        print("\n")


        # Display earliest, most recent, and most common year of birth
        common_year_birth=df["Birth Year"].mode()
        print("Common birth year for users:")
        print(common_year_birth)
        print("\n")

        earliest_year_birth=df["Birth Year"].min()
        print("earliest year of birth for users:")
        print(earliest_year_birth)
        print("\n")

        recent_year_birth=df["Birth Year"].max()
        print("recent year of birth for users:")
        print(recent_year_birth)
        print("\n")


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def display_raw_data(df): 

    """displays 5 lines by 5 lines of raw data based on input if the answer is no stop display and restart till user ends the program"""
    print(len(df.index)-1)      
    display_flag = True
    row_index_start=0
    row_index_end=4
    while display_flag and row_index_start <= len(df.index)-1:
        try:        
            display_string=input("Do you want to see 5 lines for raw data, please enter yes or no:").lower()
            if display_string == "yes":
                display_flag=True
                if row_index_end > len(df.index)-1:
                    print(df.iloc[row_index_start:,:])
                else:
                    print(df.iloc[row_index_start:row_index_end+1,:])
                row_index_start=row_index_end+1
                row_index_end=row_index_start+4        
            else:
                break
        except KeyboardInterrupt:
            sys.exit()
                
                

def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df,month,day)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df,city)
        display_raw_data(df.head(100))

        try:
            restart = input('\nWould you like to restart? Enter yes or no.\n')
            if restart.lower() != 'yes':
                break
        except KeyboardInterrupt:
            print("Try again by re-running the script") 
            sys.exit()

if __name__ == "__main__":
	main()